﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;

namespace Lecture_7_3_HomewWork
{
    public partial class frm_Main : Form
    {
        int childForm_count = 0;

      

        public frm_Main()
        {
            InitializeComponent();

            
                
           
        }      

        void check_active()
        {
            if ((frm_note)ActiveMdiChild != null)
                m_save.Enabled = m_saveAs.Enabled = m_undo.Enabled = m_redo.Enabled = m_cut.Enabled = m_copy.Enabled = m_paste.Enabled = m_selectAll.Enabled = m_process.Enabled = m_vertical.Enabled = m_horisantal.Enabled = m_caseCade.Enabled = m_color.Enabled = m_font.Enabled = true;
            else

                m_save.Enabled = m_saveAs.Enabled = m_undo.Enabled = m_redo.Enabled = m_cut.Enabled = m_copy.Enabled = m_paste.Enabled = m_selectAll.Enabled = m_process.Enabled = m_vertical.Enabled = m_horisantal.Enabled = m_caseCade.Enabled = m_color.Enabled = m_font.Enabled = false;
        }

       

         private void frm_Main_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            this.IsMdiContainer = true;
            this.WindowState = FormWindowState.Maximized;

            check_active();
        }

        private void m_new_Click(object sender, EventArgs e)
        {           

            frm_note f_note = new frm_note();
            f_note.MdiParent = this;
            f_note.Text = "Window " + childForm_count;
            f_note.Tag = "";
            f_note.Show();

           

            ToolStripMenuItem m_windowform;
            m_windowform = new ToolStripMenuItem();

            m_windowform.Name = "Window " + childForm_count;
            m_windowform.Size = new System.Drawing.Size(234, 22);
            m_windowform.Text = "Window " + childForm_count;
            this.m_window.DropDownItems.Add(m_windowform);
           

            childForm_count++;

            check_active();

            // دالة حدث الضغط click على القائمة يقوم بالتركيز على النموذج الذي نصها يساوي نص التي تم الضغط عليها
            m_windowform.Click += my_window_focus_click;

            // انشاء دالة حدث بعد الكتابة في ال textbox للنموذج المنشئ
            f_note.textBox1.TextChanged += txt_TextChanged;

            // ماداخل دالة بعد الضغط txt_TextChanged
            string str = ((frm_note)ActiveMdiChild).textBox1.Text;
            ((frm_note)ActiveMdiChild).stk_undo.Push(str);
            
        }     

        // دالة التركيز على النموذج الذي يقابلها
        private void my_window_focus_click(object sender, EventArgs e)
        {
            
            // لاغلاق النموذج النشط  وقبل ذلك يتحقق ان كان هناك نموذج نشط ام لا 
            if (this.ActiveMdiChild != null)
            {
                for (int i = 1; i < Application.OpenForms.Count; i++)
                {
                    // sender.ToString() تعيد لي اسم الذي ضغطت علية
                    if (Application.OpenForms[i].Text == sender.ToString())
                    {
                        Application.OpenForms[i].Focus();
                        return;                     
                    }
                }              
            }

            check_active();

        }
        private void m_open_Click(object sender, EventArgs e)
        {

            OpenFileDialog OpenDialog = new OpenFileDialog();
            OpenDialog.Title = "Open";
            OpenDialog.Filter = "TExt Files|*.txt";
            try
            {
                if (OpenDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {                   
                    string str = "";

                    FileStream fsr = File.Open(OpenDialog.FileName, FileMode.Open, FileAccess.Read);  // فتح ملف للقراءة منه الى الشاشة
                    StreamReader sr = new StreamReader(fsr);  // تعريف كائن من مجرى القراءة ليقرء من الملف بدون التحويل الى سلسة
                    str = sr.ReadToEnd(); // القراءة من المجرى الى السلسة 
                    
                    // اذا لم يكن هناك نموذج مفتوح او نشط فقم ب‘ستدعاء حدث الانشاء
                    if ((frm_note)ActiveMdiChild == null)
                        m_new_Click(sender, e);

                    
                    ((frm_note)ActiveMdiChild).textBox1.Text = str;
                    ((frm_note)ActiveMdiChild).textBox1.SelectionStart = ((frm_note)ActiveMdiChild).textBox1.Text.Length - 1;

                    // لتخزين مسار الملف الذي تم فتحة
                    ((frm_note)ActiveMdiChild).Tag = OpenDialog.FileName.ToString();                                       
                    
                    
                    sr.Close();         // اغلاق مجرى القراءة
                    fsr.Close();         // اغلاق الملف
                }
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Invalid File Format");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }           
        }

        // دالة لحفظ نص  المفكرة str_txt الى الملف بالمسار str_path                            
        void save_file(string str_path, string str_txt)
        {
            FileStream fsw = File.Open(str_path, FileMode.Create, FileAccess.Write);  // انشاء ملف للكتابه عليه 
            StreamWriter sw = new StreamWriter(fsw);  // تعريف كائن من مجرى الكتابة ليكتب على الملف بدون التحويل الى بايت                              
            sw.WriteLine(str_txt);                    // طباعة السلسة الى مجرى الكتابة
            sw.Close();                               // اغلاق مجرى الكتابة
            fsw.Close();                              // اغلاق الملف
        }

        // زر حفظ 
        private void m_save_Click(object sender, EventArgs e)
        {
            if ((frm_note)ActiveMdiChild != null)
            {
                string str_path = ((frm_note)ActiveMdiChild).Tag.ToString();
                string str_txt = ((frm_note)ActiveMdiChild).textBox1.Text; //  سلسلة من المفكرة                    
                    
                // اذا كان المسار قد تم انشاءة مسبقا
                if (str_path != "")
                {                    
                    // دالة لحفظ نص  المفكرة str_txt الى الملف بالمسار str_path                           
                    save_file(str_path, str_txt);
                }
                else  // اذا كان المسار لم يتم انشاءة مسبقا فنستدعي دالة حدث زر حفظ بإسم
                {                   
                    m_saveAs_Click(sender, e);
                }
            }
            else
                MessageBox.Show("لايوجد ملف نصي لحفظة قم بالفتح اولا");
        }

        // زر حفظ باسم جديد
        private void m_saveAs_Click(object sender, EventArgs e)
        {
            if ((frm_note)ActiveMdiChild != null)
            {
                SaveFileDialog SaveDialog = new SaveFileDialog();
                SaveDialog.Title = "Save";
                SaveDialog.Filter = "TExt Files|*.txt";
                try
                {
                    if (SaveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        string str_path = SaveDialog.FileName.ToString();
                        string str_txt = ((frm_note)ActiveMdiChild).textBox1.Text; //  سلسلة من المفكرة                    

                        // دالة لحفظ نص  المفكرة str_txt الى الملف بالمسار str_path
                        save_file(str_path, str_txt);

                        // بعد عملية الحفظ نحتفظ بالمسار
                        ((frm_note)ActiveMdiChild).Tag = str_path;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            else
                MessageBox.Show("لايوجد ملف نصي لحفظة قم بالفتح اولا");
        }

        // اغلاق النموذج النشط
        private void m_Close_Click(object sender, EventArgs e)
        {
            // لاغلاق النموذج النشط  وقبل ذلك يتحقق ان كان هناك نموذج نشط ام لا 
            if (this.ActiveMdiChild != null)
            {
                // لحذف النص من ال window الخاص ب النموذج                
                int x = m_window.DropDownItems.IndexOfKey(((frm_note)ActiveMdiChild).Text);
                m_window.DropDownItems.RemoveAt(x);

                this.ActiveMdiChild.Close();
            }

            check_active();

        }

        // اغلاق جميع نماذج الابناء
        private void m_CloseAll_Click(object sender, EventArgs e)
        {            
            //// لحذف النص من ال window الخاص ب النموذج                
            //for (int i = 0; i < this.MdiChildren.Length; i++)
            //{
            //    int x = m_window.DropDownItems.IndexOfKey(this.MdiChildren[i].Text);
            //    m_window.DropDownItems.RemoveAt(x);
            //}



            //  او الطريقة جميع نماذج الابناء مع حذف النص من ال window الخاص ب النموذج  
            for (int i = 1; i < Application.OpenForms.Count; )
            {
                // لحذف النص من ال window الخاص ب النموذج  
                int x = m_window.DropDownItems.IndexOfKey(Application.OpenForms[i].Text);
                m_window.DropDownItems.RemoveAt(x);
                
                // لغلق النموذج
                Application.OpenForms[1].Close();

            }

            check_active();
            childForm_count = 0;

        }



        //الخروج من التطبيق
        private void m_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();                                  
        }

        // دالة عند بعد الكتابة
        private void txt_TextChanged(object sender, EventArgs e)
        {        
            string str = ((frm_note)ActiveMdiChild).textBox1.Text;
            ((frm_note)ActiveMdiChild).stk_undo.Push(str);
            
        }

        // تراجع للخلف
        private void m_undo_Click(object sender, EventArgs e)
        {

            //((frm_note)ActiveMdiChild).textBox1.Undo();


            if (((frm_note)ActiveMdiChild).stk_undo.Count<string>() > 0)
            {
                string str = ((frm_note)ActiveMdiChild).stk_undo.Pop();
                ((frm_note)ActiveMdiChild).stk_redo.Push(str);
                // نخرجة مرة اخرى لانه قد عاد في دالة التغيير
                if (((frm_note)ActiveMdiChild).stk_undo.Count<string>() > 0)
                    str = ((frm_note)ActiveMdiChild).stk_undo.Pop();
                ((frm_note)ActiveMdiChild).stk_redo.Push(str);

                ((frm_note)ActiveMdiChild).textBox1.Text = str;

                // لنقل المؤشر الى اخر موقع
                ((frm_note)ActiveMdiChild).textBox1.SelectionStart = ((frm_note)ActiveMdiChild).textBox1.Text.Length;

            }

        }

        // تراجع للأمام
        private void m_redo_Click(object sender, EventArgs e)
        {

            //((Form2)ActiveMdiChild).textBox1.redo();           
            if (((frm_note)ActiveMdiChild).stk_redo.Count<string>() > 0)
            {

                string str = ((frm_note)ActiveMdiChild).stk_redo.Pop();
                ((frm_note)ActiveMdiChild).stk_undo.Push(str);
                // نخرجة مرة اخرى لانه قد عاد في دالة التغيير
                if (((frm_note)ActiveMdiChild).stk_redo.Count<string>() > 0)
                    str = ((frm_note)ActiveMdiChild).stk_redo.Pop();
                ((frm_note)ActiveMdiChild).stk_undo.Push(str);

                ((frm_note)ActiveMdiChild).textBox1.Text = str;


                // لنقل المؤشر الى اخر موقع
                ((frm_note)ActiveMdiChild).textBox1.SelectionStart = ((frm_note)ActiveMdiChild).textBox1.Text.Length;


            }
        }

        private void m_cut_Click(object sender, EventArgs e)
        {
           
            ((frm_note)ActiveMdiChild).textBox1.Cut();
        }


        private void m_copy_Click(object sender, EventArgs e)
        {
            ((frm_note)ActiveMdiChild).textBox1.Copy();
        }


        private void m_paste_Click(object sender, EventArgs e)
        {
           
            ((frm_note)ActiveMdiChild).textBox1.Paste();
        }

        private void m_selectAll_Click(object sender, EventArgs e)
        {
           
            ((frm_note)ActiveMdiChild).textBox1.SelectAll();
        }

        // دالة لإختبار اسم المواطن ان كان رباعيا ام لا
        string space_process(string str)
        {
            str = str.Trim();           

            for (int i = 0; i < str.Length - 1; i++)
            {
                if (str[i] == ' ' && str[i + 1] == ' ')
                {
                    str = str.Remove(i + 1, 1); // حذف من الموقع  i+1  وبطول   واحد 
                    i--; // ثم نعيد المؤشر
                }
            }
                       
            return str ;
        }

        private void m_process_Click(object sender, EventArgs e)
        {
            string str = space_process(((frm_note)ActiveMdiChild).textBox1.Text);

            ((frm_note)ActiveMdiChild).textBox1.Text = str;
           
        }

        // ترتيب عمودي
        private void m_vertical_Click(object sender, EventArgs e)
        {
            // اما الطريقة
            // this.LayoutMdi(MdiLayout.TileVertical);
            //


            // او الطريقة
            if (Application.OpenForms.Count > 1)
            {
                //int width = this.Width / (Application.OpenForms.Count - 1);
                //int height = this.Height;
                // او
                int width = this.ClientRectangle.Width / (Application.OpenForms.Count - 1);
                int height = this.ClientRectangle.Height;

                for (int i = 1; i < Application.OpenForms.Count; i++)
                {
                    Application.OpenForms[i].Width = width;
                    Application.OpenForms[i].Height = height;
                    Application.OpenForms[i].Left = (i - 1) * width + this.ClientRectangle.Left;
                    Application.OpenForms[i].Top = this.ClientRectangle.Top;
                }
            }

        }

        // ترتيب افقي
        private void m_horisantal_Click(object sender, EventArgs e)
        {

            // اما الطريقة
            this.LayoutMdi(MdiLayout.TileHorizontal);

            // او الطريقة
            if (Application.OpenForms.Count > 1)
            {
                //int width = this.Width ;
                //int height = this.Height/ (Application.OpenForms.Count - 1);
                // او
                int width = this.ClientRectangle.Width;
                int height = this.ClientRectangle.Height / (Application.OpenForms.Count - 1);

                for (int i = 1; i < Application.OpenForms.Count; i++)
                {
                    Application.OpenForms[i].Width = width;
                    Application.OpenForms[i].Height = height;
                    Application.OpenForms[i].Left = this.ClientRectangle.Left;
                    Application.OpenForms[i].Top = (i - 1) * height + this.ClientRectangle.Top;
                }
            }
        }

        // ترتيب قطري
        private void m_caseCade_Click(object sender, EventArgs e)
        {

            // اما الطريقة
            //this.LayoutMdi(MdiLayout.Cascade);

            // او الطريقة
            if (Application.OpenForms.Count > 1)
            {
                //int width = this.Width/4 ;
                //int height = this.Height/4;
                // او
                int width = this.ClientRectangle.Width / 4;
                int height = this.ClientRectangle.Height / 4;
                width *= 3;
                height *= 3;
                for (int i = 1; i < Application.OpenForms.Count; i++)
                {

                    Application.OpenForms[i].Width = width;
                    Application.OpenForms[i].Height = height;
                    Application.OpenForms[i].Left = (i - 1) * 25 + this.ClientRectangle.Left;
                    Application.OpenForms[i].Top = (i - 1) * 25 + this.ClientRectangle.Top;
                }
            }
        }


        private void m_font_Click(object sender, EventArgs e)
        {           
            FontDialog font = new FontDialog();
            try
            {
                if (font.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    ((frm_note)ActiveMdiChild).textBox1.Font = (Font)font.Font.Clone();
                }
            }
            catch (Exception)
            {
            }            
        }

        private void m_color_Click(object sender, EventArgs e)
        {
            ColorDialog colour = new ColorDialog();
            try
            {

                if (colour.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    ((frm_note)ActiveMdiChild).textBox1.ForeColor = colour.Color;
                }
            }
            catch (Exception)
            {
            }
        }

        

       

    }
}
