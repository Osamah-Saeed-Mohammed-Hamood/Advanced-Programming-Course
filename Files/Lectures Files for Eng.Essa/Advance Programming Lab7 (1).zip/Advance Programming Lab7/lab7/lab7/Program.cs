﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7
{
    public class CustomShapeButton : Button
    {
        public enum ButtonShape { Square, Circle }
        public ButtonShape Shape { set; get; } = ButtonShape.Square;
        protected override void OnPaint(PaintEventArgs pevent)
        {
            GraphicsPath path = new GraphicsPath();

            if (Shape == ButtonShape.Circle)
            {
                path.AddEllipse(0, 0, this.Width, this.Height);
            }
            else
            {
                path.AddRectangle(new Rectangle(0, 0, this.Width, this.Height));
            }

            this.Region = new Region(path);
            base.OnPaint(pevent);
        }

        protected override void OnMouseEnter(EventArgs e) => this.BackColor = Color.LightBlue;
        protected override void OnMouseLeave(EventArgs e) => this.BackColor = Color.LightGray;
    }
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
