package lab7;

public class Student extends Person {
    private int id;
    private Courses course;

    public Student(String name, Date birthDate, String address, int id, Courses course) {
        super(name, birthDate, address);
        this.id = id;
        this.course = course;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Courses getCourse() {
        return course;
    }

    public void setCourse(Courses course) {
        this.course = course;
    }

    @Override
    public void print() {
        super.print();
        System.out.println("ID: " + id);
        course.print();
    }

    public static void compareIds(Student s1, Student s2) {
        if (s1.getId() == s2.getId()) {
            System.out.println(s1.getName() + " has the same ID as " + s2.getName());
        } else {
            System.out.println(s1.getName() + " has a different ID than " + s2.getName());
        }
    }
}
