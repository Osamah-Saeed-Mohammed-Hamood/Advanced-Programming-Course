
using MySql.Data.MySqlClient;

namespace lab7
{
    public class DBConnection
    {
        private static string connectionString = "server=localhost;user id=root;password=;database=dbtest;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
