package lab7;

public class Person {
    private String name;
    private Date birthDate;
    private String address;

    public Person() {
        this.name = "";
        this.birthDate = new Date();
        this.address = "";
    }

    public Person(String name, Date birthDate, String address) {
        this.name = name;
        this.birthDate = birthDate;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void print() {
        System.out.println("Name: " + name + ", Address: " + address);
        birthDate.print();
    }
}
