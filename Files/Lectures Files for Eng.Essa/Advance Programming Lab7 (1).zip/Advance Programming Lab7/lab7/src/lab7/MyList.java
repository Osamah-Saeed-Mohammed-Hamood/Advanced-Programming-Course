
package lab7;

public class MyList {

    private int Length;
    private Student[] students;

    public MyList(int Size) {
        students = new Student[Size];
        Length = 0;
    }

    public void addStudent(Student st) {
        students[Length] = st;
        Length++;
    }

    public void printAllStudents() {
        for (int i = 0; i < Length; i++) {
            students[i].print();
        }
    }

    public int getLenght() {
        return Length;
    }

    public Student[] getList() {
        return students;
    }

    public Student getList(int index) {
        return students[index];
    }

    public double printStudentsWithHighestMark() {
        double max = 0;
        for (int i = 0; i <students.length; i++) {
            if (max > students[i].getCourse().getMark()) {
                max = students[i].getCourse().getMark();
            }
        }
        return max;
    }

    public int searchById(int id) {
        int pos = -1;
        for (int i = 0; i < Length; i++) {
            if (students[i].getId()== id) {
                pos = i;
            }
        }
        return pos;
    }

    public boolean IsEmpte() {
        if (Length == 0) {
            return true;
        } else {
            return false;
        }
    }

    public boolean IsFull(int size) {
        if (Length == size) {
            return true;
        } else {
            return false;
        }
    }
     public void printStudentsWithGrades() {
        for (Student student : students) {
            double mark = student.getCourse().getMark();
            String grade;
            if (mark > 85) {
                grade = "A";
            } else if (mark > 75) {
                grade = "B";
            } else if (mark > 65) {
                grade = "C";
            } else if (mark >= 50) {
                grade = "D";
            } else {
                grade = "F";
            }
            System.out.println("ID: " + student.getId() + ", Name: " + student.getName() + ", Grade: " + grade);
        }
    }
        public void printSuccessfulStudents(MyList Liststudents) {
        System.out.println("Successful Liststudents:");
        for (int i=0;i< Liststudents.students.length;i++) {
            if (Liststudents.students[i].getCourse().getMark() >= 50) {
               Liststudents.students[i].print();
            }
            else
                 System.out.println("No Successful Students:");
        }
    }
        
       public double calculateAverageMark()
        {
        if(students.length==0)return 0;
        double sum=0;
            for (Student student : students) {
                sum+=student.getCourse().getMark();
                
            }
            return sum/students.length;
        }
        

}

