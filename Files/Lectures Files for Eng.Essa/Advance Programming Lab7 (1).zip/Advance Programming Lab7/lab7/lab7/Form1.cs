using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace lab7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.Fixed3D;
        //    this.BackColor = Color.MediumPurple;
          //  this.Width = this.Height = 300;
        }

        //protected override void OnPaint(PaintEventArgs e)
        //{
        //    //base.OnPaint(e);
        //    GraphicsPath path = new GraphicsPath();
        //    path.AddEllipse(0, 0, this.Width, this.Height);
        //    this.Region = new Region(path);
        //}
        MySqlConnection conn= DBConnection.GetConnection();
      private void Button1_Click(object sender, EventArgs e)
        {
          dataGridView1.DataSource=UserData.GetAllUsers();
         

        }

        private void Insert_Click(object sender, EventArgs e)
        {
           UserData.InsertUser(txtName.Text.Trim(),txtEmail.Text.Trim());
        }
         private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            UserData.UpdateUser(id, txtName.Text, txtEmail.Text);
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            UserData.DeleteUser(id);
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void DbButtonControl3_Load(object sender, EventArgs e)
        {

        }

        private void dbButtonControl1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource=UserData.GetAllUsers();    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserData.DeleteUser(int.Parse(txtId.Text));
            dataGridView1.DataSource = UserData.GetAllUsers();
        }
    }
}
