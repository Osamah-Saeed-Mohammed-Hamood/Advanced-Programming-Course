﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab7
{
    public partial class DBButtonControl : UserControl
    {
        public DBButtonControl()
        {
            InitializeComponent();
        }

        public string OperationType { get; set; }
        public string TableName { get; set; }
        public Dictionary<string, string> FieldValues { get; set; }

        private void btnAction_Click(object sender, EventArgs e)
        {
            switch (OperationType)
            {
                case "Insert":
                    InsertData();
                    break;
                case "Update":
                    UpdateData();
                    break;
                case "Delete":
                    DeleteData();
                    break;
                default:
                    MessageBox.Show("Operation type is not defined.");
                    break;
            }
        }

        private void InsertData()
        {
            if (FieldValues == null || FieldValues.Count == 0)
            {
                MessageBox.Show("Please provide valid data.");
                return;
            }

            foreach (var field in FieldValues)
            {
                UserData.InsertUser(field.Key, field.Value);
            }

            MessageBox.Show("Data inserted successfully.");
        }

        private void UpdateData()
        {
            if (FieldValues == null || FieldValues.Count == 0)
            {
                MessageBox.Show("Please provide valid data.");
                return;
            }

            foreach (var field in FieldValues)
            {
                UserData.UpdateUser(int.Parse(field.Key), field.Value, "new_email");
            }

            MessageBox.Show("Data updated successfully.");
        }

        private void DeleteData()
        {
            if (FieldValues == null || FieldValues.Count == 0)
            {
                MessageBox.Show("Please provide valid data.");
                return;
            }

            foreach (var field in FieldValues)
            {
                UserData.DeleteUser(int.Parse(field.Key));
            }

            MessageBox.Show("Data deleted successfully.");
        }
    }
}
