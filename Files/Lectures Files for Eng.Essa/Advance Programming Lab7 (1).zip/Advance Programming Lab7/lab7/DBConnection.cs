
using MySql.Data.MySqlClient;

namespace MySQL_UserManager
{
    public class DBConnection
    {
        private static string connectionString = "server=localhost;user id=root;password=;database=testdb;";

        public static MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
