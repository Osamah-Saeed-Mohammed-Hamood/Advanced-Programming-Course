package lab7;

public class Courses {
    private int courseNumber;
    private double mark;
    private String name;
    private Date recordDate;

    public Courses() {
        this.courseNumber = 0;
        this.mark = 0.0;
        this.name = "";
        this.recordDate = new Date();
    }

    public Courses(int courseNumber, String name, Date recordDate, double mark) {
        this.courseNumber = courseNumber;
        this.name = name;
        this.recordDate = recordDate;
        this.mark = mark;
    }

    public int getCourseNumber() {
        return courseNumber;
    }

    public void setCourseNumber(int courseNumber) {
        this.courseNumber = courseNumber;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getRecordDate() {
        return recordDate;
    }

    public void setRecordDate(Date recordDate) {
        this.recordDate = recordDate;
    }

    public void print() {
        System.out.println("Course Number: " + courseNumber + ", Name: " + name + ", Mark: " + mark);
        recordDate.print();
    }
}
