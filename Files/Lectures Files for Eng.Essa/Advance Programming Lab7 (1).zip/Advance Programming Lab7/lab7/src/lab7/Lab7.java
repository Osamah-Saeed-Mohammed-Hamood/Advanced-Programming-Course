package lab7;

import java.util.Scanner;

public class Lab7 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of students:");
        int size = scanner.nextInt();
        MyList studentList = new MyList(size);

        int choice;
        do {
            printMenu();
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    if (!studentList.IsFull(size)) {
                        Student newStudent = createStudent(scanner);
                        studentList.addStudent(newStudent);
                    } else {
                        System.out.println("The list is full!");
                    }
                    break;

                case 2:
                    studentList.printAllStudents();
                    break;

                case 3:
                    searchStudentById(scanner, studentList);
                    break;

                case 4:
                    studentList.printSuccessfulStudents(studentList);
                    break;

                case 5:
                double    maxMark= studentList.printStudentsWithHighestMark();
                     System.out.println("Maximum mark: " + maxMark);
        for (Student student : studentList.getList()) {
            if (student.getCourse().getMark() == maxMark) {
                student.print();
            }} 
                    break;
        
                case 6:
                    System.out.println("Average mark: " + studentList.calculateAverageMark());
                    break;

                case 7:
                    studentList.printStudentsWithGrades();
                    break;

                case 8:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Please choose a valid option (1-8).");
            }
        } while (choice != 8);

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\nMenu:");
        System.out.println("1- Add Student");
        System.out.println("2- Print all Students");
        System.out.println("3- Search for a Student by ID");
        System.out.println("4- List of Successful Students");
        System.out.println("5- Student(s) with the Highest Mark");
        System.out.println("6- Average Mark");
        System.out.println("7- Print Students with Grades");
        System.out.println("8- Exit");
        System.out.print("Choose an option: ");
    }

    private static Student createStudent(Scanner scanner) {
        System.out.print("Enter student's name: ");
        String name = scanner.next();

        System.out.println("Enter student's birth date:");
        Date birthDate = createDate(scanner);

        System.out.print("Enter student's address: ");
        String address = scanner.next();

        System.out.print("Enter student's ID: ");
        int id = scanner.nextInt();

        System.out.println("Enter course details:");
        System.out.print("Course number: ");
        int courseNumber = scanner.nextInt();

        System.out.print("Course name: ");
        String courseName = scanner.next();

        System.out.print("Course mark: ");
        double mark = scanner.nextDouble();

        System.out.println("Enter course record date:");
        Date courseDate = createDate(scanner);

        Courses course = new Courses(courseNumber, courseName, courseDate, mark);
        return new Student(name, birthDate, address, id, course);
    }

    private static Date createDate(Scanner scanner) {
        System.out.print("Day: ");
        int day = scanner.nextInt();

        System.out.print("Month: ");
        int month = scanner.nextInt();

        System.out.print("Year: ");
        int year = scanner.nextInt();

        return new Date(day, month, year);
    }

    private static void searchStudentById(Scanner scanner, MyList studentList) {
        System.out.print("Enter student ID to search: ");
        
        int id =studentList.searchById(scanner.nextInt()); 

        if (id != -1) {
            studentList.getList(id).print();
        } else {
            System.out.println("Student not found.");
        }
    }
}
