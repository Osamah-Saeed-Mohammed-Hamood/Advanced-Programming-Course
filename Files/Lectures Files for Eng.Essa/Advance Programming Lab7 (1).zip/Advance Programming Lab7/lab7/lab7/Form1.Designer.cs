﻿namespace lab7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.insert = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.dbButtonControl1 = new lab7.DBButtonControl();
            this.customShapeButton1 = new lab7.CustomShapeButton();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 196);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(611, 173);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(277, 35);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(177, 51);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(201, 135);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(119, 24);
            this.txtEmail.TabIndex = 2;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(201, 92);
            this.txtName.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(119, 24);
            this.txtName.TabIndex = 3;
            // 
            // insert
            // 
            this.insert.Location = new System.Drawing.Point(71, 35);
            this.insert.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.insert.Name = "insert";
            this.insert.Size = new System.Drawing.Size(177, 51);
            this.insert.TabIndex = 4;
            this.insert.Text = "insert";
            this.insert.UseVisualStyleBackColor = true;
            this.insert.Click += new System.EventHandler(this.Insert_Click);
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(201, 168);
            this.txtId.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(119, 24);
            this.txtId.TabIndex = 5;
            // 
            // dbButtonControl1
            // 
            this.dbButtonControl1.FieldValues = null;
            this.dbButtonControl1.Location = new System.Drawing.Point(458, 48);
            this.dbButtonControl1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.dbButtonControl1.Name = "dbButtonControl1";
            this.dbButtonControl1.OperationType = null;
            this.dbButtonControl1.Size = new System.Drawing.Size(155, 126);
            this.dbButtonControl1.TabIndex = 6;
            this.dbButtonControl1.TableName = null;
            this.dbButtonControl1.Load += new System.EventHandler(this.dbButtonControl1_Load);
            // 
            // customShapeButton1
            // 
            this.customShapeButton1.Location = new System.Drawing.Point(443, 63);
            this.customShapeButton1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.customShapeButton1.Name = "customShapeButton1";
            this.customShapeButton1.Shape = lab7.CustomShapeButton.ButtonShape.Circle;
            this.customShapeButton1.Size = new System.Drawing.Size(118, 94);
            this.customShapeButton1.TabIndex = 7;
            this.customShapeButton1.Text = "customShapeButton1";
            this.customShapeButton1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(11, 106);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(177, 51);
            this.button2.TabIndex = 8;
            this.button2.Text = "delete";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 332);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.customShapeButton1);
            this.Controls.Add(this.dbButtonControl1);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.insert);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button insert;
        private System.Windows.Forms.TextBox txtId;
        private DBButtonControl dbButtonControl1;
        private CustomShapeButton customShapeButton1;
        private System.Windows.Forms.Button button2;
    }
}

