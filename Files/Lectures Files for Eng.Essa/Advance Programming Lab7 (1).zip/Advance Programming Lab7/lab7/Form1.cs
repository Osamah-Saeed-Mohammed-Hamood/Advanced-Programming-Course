
using System;
using System.Data;
using System.Windows.Forms;

namespace MySQL_UserManager
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            UserData.InsertUser(txtName.Text, txtEmail.Text);
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            UserData.UpdateUser(id, txtName.Text, txtEmail.Text);
            dataGridView1.DataSource = UserData.GetAllUsers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtId.Text);
            UserData.DeleteUser(id);
            dataGridView1.DataSource = UserData.GetAllUsers();
        }
    }
}
