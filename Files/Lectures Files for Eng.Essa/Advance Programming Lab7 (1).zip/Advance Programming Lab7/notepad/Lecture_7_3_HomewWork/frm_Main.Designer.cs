﻿namespace Lecture_7_3_HomewWork
{
    partial class frm_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.m_color = new System.Windows.Forms.ToolStripMenuItem();
            this.m_font = new System.Windows.Forms.ToolStripMenuItem();
            this.m_format = new System.Windows.Forms.ToolStripMenuItem();
            this.m_caseCade = new System.Windows.Forms.ToolStripMenuItem();
            this.m_horisantal = new System.Windows.Forms.ToolStripMenuItem();
            this.m_vertical = new System.Windows.Forms.ToolStripMenuItem();
            this.m_window = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.m_process = new System.Windows.Forms.ToolStripMenuItem();
            this.m_selectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.m_paste = new System.Windows.Forms.ToolStripMenuItem();
            this.m_copy = new System.Windows.Forms.ToolStripMenuItem();
            this.m_redo = new System.Windows.Forms.ToolStripMenuItem();
            this.m_undo = new System.Windows.Forms.ToolStripMenuItem();
            this.m_edit = new System.Windows.Forms.ToolStripMenuItem();
            this.m_cut = new System.Windows.Forms.ToolStripMenuItem();
            this.m_Exit = new System.Windows.Forms.ToolStripMenuItem();
            this.m_CloseAll = new System.Windows.Forms.ToolStripMenuItem();
            this.m_Close = new System.Windows.Forms.ToolStripMenuItem();
            this.m_save = new System.Windows.Forms.ToolStripMenuItem();
            this.m_open = new System.Windows.Forms.ToolStripMenuItem();
            this.m_new = new System.Windows.Forms.ToolStripMenuItem();
            this.m_file = new System.Windows.Forms.ToolStripMenuItem();
            this.m_saveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // m_color
            // 
            this.m_color.Name = "m_color";
            this.m_color.Size = new System.Drawing.Size(99, 22);
            this.m_color.Text = "اللون";
            this.m_color.Click += new System.EventHandler(this.m_color_Click);
            // 
            // m_font
            // 
            this.m_font.Name = "m_font";
            this.m_font.Size = new System.Drawing.Size(99, 22);
            this.m_font.Text = "الخط";
            this.m_font.Click += new System.EventHandler(this.m_font_Click);
            // 
            // m_format
            // 
            this.m_format.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_font,
            this.m_color});
            this.m_format.Name = "m_format";
            this.m_format.Size = new System.Drawing.Size(50, 20);
            this.m_format.Text = "تنسيق";
            // 
            // m_caseCade
            // 
            this.m_caseCade.Name = "m_caseCade";
            this.m_caseCade.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.C)));
            this.m_caseCade.Size = new System.Drawing.Size(234, 22);
            this.m_caseCade.Text = "ترتيب قطري CaseCade";
            this.m_caseCade.Click += new System.EventHandler(this.m_caseCade_Click);
            // 
            // m_horisantal
            // 
            this.m_horisantal.Name = "m_horisantal";
            this.m_horisantal.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.H)));
            this.m_horisantal.Size = new System.Drawing.Size(234, 22);
            this.m_horisantal.Text = " تريتيب افقي Horisantal";
            this.m_horisantal.Click += new System.EventHandler(this.m_horisantal_Click);
            // 
            // m_vertical
            // 
            this.m_vertical.Name = "m_vertical";
            this.m_vertical.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.V)));
            this.m_vertical.Size = new System.Drawing.Size(234, 22);
            this.m_vertical.Text = "ترتيب عمودي Vertical";
            this.m_vertical.Click += new System.EventHandler(this.m_vertical_Click);
            // 
            // m_window
            // 
            this.m_window.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_vertical,
            this.m_horisantal,
            this.m_caseCade,
            this.toolStripSeparator1});
            this.m_window.Name = "m_window";
            this.m_window.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.W)));
            this.m_window.Size = new System.Drawing.Size(51, 20);
            this.m_window.Text = "النوافذ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(231, 6);
            // 
            // m_process
            // 
            this.m_process.Name = "m_process";
            this.m_process.ShortcutKeyDisplayString = "";
            this.m_process.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.m_process.Size = new System.Drawing.Size(174, 22);
            this.m_process.Text = "معالجة";
            this.m_process.Click += new System.EventHandler(this.m_process_Click);
            // 
            // m_selectAll
            // 
            this.m_selectAll.Name = "m_selectAll";
            this.m_selectAll.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.m_selectAll.Size = new System.Drawing.Size(174, 22);
            this.m_selectAll.Text = "تحديد الكل";
            this.m_selectAll.Click += new System.EventHandler(this.m_selectAll_Click);
            // 
            // m_paste
            // 
            this.m_paste.Name = "m_paste";
            this.m_paste.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.m_paste.Size = new System.Drawing.Size(174, 22);
            this.m_paste.Text = "لصق";
            this.m_paste.Click += new System.EventHandler(this.m_paste_Click);
            // 
            // m_copy
            // 
            this.m_copy.Name = "m_copy";
            this.m_copy.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.m_copy.Size = new System.Drawing.Size(174, 22);
            this.m_copy.Text = "نسخ";
            this.m_copy.Click += new System.EventHandler(this.m_copy_Click);
            // 
            // m_redo
            // 
            this.m_redo.Name = "m_redo";
            this.m_redo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.m_redo.Size = new System.Drawing.Size(174, 22);
            this.m_redo.Text = "تراجع للخلف";
            this.m_redo.Click += new System.EventHandler(this.m_redo_Click);
            // 
            // m_undo
            // 
            this.m_undo.Name = "m_undo";
            this.m_undo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.m_undo.Size = new System.Drawing.Size(174, 22);
            this.m_undo.Text = "تراجع للأمام";
            this.m_undo.Click += new System.EventHandler(this.m_undo_Click);
            // 
            // m_edit
            // 
            this.m_edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_undo,
            this.m_redo,
            this.m_cut,
            this.m_copy,
            this.m_paste,
            this.m_selectAll,
            this.m_process});
            this.m_edit.Name = "m_edit";
            this.m_edit.Size = new System.Drawing.Size(45, 20);
            this.m_edit.Text = "تحرير";
            // 
            // m_cut
            // 
            this.m_cut.Name = "m_cut";
            this.m_cut.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.m_cut.Size = new System.Drawing.Size(174, 22);
            this.m_cut.Text = "قص";
            this.m_cut.Click += new System.EventHandler(this.m_cut_Click);
            // 
            // m_Exit
            // 
            this.m_Exit.Name = "m_Exit";
            this.m_Exit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.m_Exit.Size = new System.Drawing.Size(207, 22);
            this.m_Exit.Text = "الخروج من التطبيق";
            this.m_Exit.Click += new System.EventHandler(this.m_Exit_Click);
            // 
            // m_CloseAll
            // 
            this.m_CloseAll.Name = "m_CloseAll";
            this.m_CloseAll.Size = new System.Drawing.Size(207, 22);
            this.m_CloseAll.Text = "إغلاق الكل";
            this.m_CloseAll.Click += new System.EventHandler(this.m_CloseAll_Click);
            // 
            // m_Close
            // 
            this.m_Close.Name = "m_Close";
            this.m_Close.Size = new System.Drawing.Size(207, 22);
            this.m_Close.Text = "إغلاق";
            this.m_Close.Click += new System.EventHandler(this.m_Close_Click);
            // 
            // m_save
            // 
            this.m_save.Name = "m_save";
            this.m_save.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.m_save.Size = new System.Drawing.Size(207, 22);
            this.m_save.Text = "حفظ";
            this.m_save.Click += new System.EventHandler(this.m_save_Click);
            // 
            // m_open
            // 
            this.m_open.Name = "m_open";
            this.m_open.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.m_open.Size = new System.Drawing.Size(207, 22);
            this.m_open.Text = "فتح";
            this.m_open.Click += new System.EventHandler(this.m_open_Click);
            // 
            // m_new
            // 
            this.m_new.Name = "m_new";
            this.m_new.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.m_new.Size = new System.Drawing.Size(207, 22);
            this.m_new.Text = "جديد";
            this.m_new.Click += new System.EventHandler(this.m_new_Click);
            // 
            // m_file
            // 
            this.m_file.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_new,
            this.m_open,
            this.m_save,
            this.m_saveAs,
            this.m_Close,
            this.m_CloseAll,
            this.m_Exit});
            this.m_file.Name = "m_file";
            this.m_file.Size = new System.Drawing.Size(42, 20);
            this.m_file.Text = "ملف";
            // 
            // m_saveAs
            // 
            this.m_saveAs.Name = "m_saveAs";
            this.m_saveAs.Size = new System.Drawing.Size(207, 22);
            this.m_saveAs.Text = "حفظ بإسم جديد";
            this.m_saveAs.Click += new System.EventHandler(this.m_saveAs_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_file,
            this.m_edit,
            this.m_window,
            this.m_format});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip1.Size = new System.Drawing.Size(548, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // frm_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 459);
            this.Controls.Add(this.menuStrip1);
            this.Name = "frm_Main";
            this.Text = "الصفحة الرئيسية";
            this.Load += new System.EventHandler(this.frm_Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem m_color;
        private System.Windows.Forms.ToolStripMenuItem m_font;
        private System.Windows.Forms.ToolStripMenuItem m_format;
        private System.Windows.Forms.ToolStripMenuItem m_caseCade;
        private System.Windows.Forms.ToolStripMenuItem m_horisantal;
        private System.Windows.Forms.ToolStripMenuItem m_vertical;
        private System.Windows.Forms.ToolStripMenuItem m_window;
        private System.Windows.Forms.ToolStripMenuItem m_process;
        private System.Windows.Forms.ToolStripMenuItem m_selectAll;
        private System.Windows.Forms.ToolStripMenuItem m_paste;
        private System.Windows.Forms.ToolStripMenuItem m_copy;
        private System.Windows.Forms.ToolStripMenuItem m_redo;
        private System.Windows.Forms.ToolStripMenuItem m_undo;
        private System.Windows.Forms.ToolStripMenuItem m_edit;
        private System.Windows.Forms.ToolStripMenuItem m_cut;
        private System.Windows.Forms.ToolStripMenuItem m_Exit;
        private System.Windows.Forms.ToolStripMenuItem m_CloseAll;
        private System.Windows.Forms.ToolStripMenuItem m_Close;
        private System.Windows.Forms.ToolStripMenuItem m_save;
        private System.Windows.Forms.ToolStripMenuItem m_open;
        private System.Windows.Forms.ToolStripMenuItem m_new;
        private System.Windows.Forms.ToolStripMenuItem m_file;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem m_saveAs;
    }
}