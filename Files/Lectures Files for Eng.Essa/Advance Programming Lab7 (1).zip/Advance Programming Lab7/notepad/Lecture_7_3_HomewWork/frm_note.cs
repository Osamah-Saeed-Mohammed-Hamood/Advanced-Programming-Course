﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lecture_7_3_HomewWork
{
    public partial class frm_note : Form
    {
        public Stack<string> stk_undo = new Stack<string>();
        public Stack<string> stk_redo = new Stack<string>();

        public frm_note()
        {
            InitializeComponent();
        }

        private void frm_note_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;  // لإخفاء شريط التحكم           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

        }
        
    }
}
